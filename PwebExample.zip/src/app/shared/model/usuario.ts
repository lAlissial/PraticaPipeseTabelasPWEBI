export class Usuario {
  id: number;
  nome: string;
  cpf: string;
  idade: number;
  telefone: string;
}
