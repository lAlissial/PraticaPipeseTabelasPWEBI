export const USUARIOS = [
  {
    nome: 'Gustavo',
    cpf: '123',
    idade: 34
  },
  {
    nome: 'Wagner',
    cpf: '124',
    idade: 32
  },
  {
    nome: 'Diniz',
    cpf: '125',
    idade: 30
  }
];
